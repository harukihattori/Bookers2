# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a2f622cc64476f854f3b001adb5dea29cef8c6806b12960a91ed55ee80fa5cb942522d651cce2a798f179e4ccfac9993ee34f1cb7a797519380d394c52f29d71'